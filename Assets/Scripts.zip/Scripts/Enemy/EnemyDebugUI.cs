using UnityEngine;
using TMPro;

public class EnemyDebugUI : MonoBehaviour
{
    public TextMeshPro text;  // << ������ Canvas Text��������ͨ TMP
    public Vector3 offset = new Vector3(0, 2.2f, 0);

    private Camera cam;
    private EnemyResources resources;
    private EnemyPoiseController poise;
    private EnemyAIController ai;

    private void Start()
    {
        cam = Camera.main;

        resources = GetComponentInParent<EnemyResources>();
        poise = GetComponentInParent<EnemyPoiseController>();
        ai = GetComponentInParent<EnemyAIController>();

        if (text == null)
            text = GetComponent<TextMeshPro>();
    }

    private void Update()
    {
        if (cam == null || text == null) return;

        // �����ָ��ŵ���ͷ��
        transform.position = resources.transform.position + offset;

        // ��Զ�����������billboard��
        transform.rotation = Quaternion.LookRotation(transform.position - cam.transform.position);

        // ����ı�
        string hp = $"HP: {Mathf.RoundToInt(resources.CurrentHP)} / {Mathf.RoundToInt(resources.MaxHP)}";
        string poiseStr = $"Poise: {Mathf.RoundToInt(poise.CurrentPoise)} / {Mathf.RoundToInt(poise.MaxPoise)}";
        string state = $"State: {ai.CurrentDebugState}";
        string reaction = $"Reaction: {poise.LastReaction}";
        string lastImpact = $"Impact: {poise.LastImpactGrade}";

        text.text = $"{hp}\n{poiseStr}\n{state}\n{reaction}\n{lastImpact}";
    }
}
