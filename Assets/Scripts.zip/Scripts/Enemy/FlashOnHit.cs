using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class FlashOnHit : MonoBehaviour
{
    [SerializeField] private Color flashColor = Color.white;
    [SerializeField] private float flashDuration = 0.08f;

    private Renderer[] renderers;
    private Color[] originalColors;

    private void Awake()
    {
        var all = GetComponentsInChildren<Renderer>();
        var list = new List<Renderer>();
        var colors = new List<Color>();

        foreach (var r in all)
        {
            var mat = r.material;
            // ֻ������ _Color ���ԵĲ��ʣ����� TMP ֮���
            if (mat != null && mat.HasProperty("_Color"))
            {
                list.Add(r);
                colors.Add(mat.color);
            }
        }

        renderers = list.ToArray();
        originalColors = colors.ToArray();
    }

    public void Trigger()
    {
        // �����Ѿ�������ʱ��Ҫ�ٿ�Э�̣��������ڶ���������
        if (!isActiveAndEnabled) return;
        if (renderers == null || renderers.Length == 0) return;

        StopAllCoroutines();
        StartCoroutine(FlashRoutine());
    }

    private IEnumerator FlashRoutine()
    {
        // ��ɫ
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null)
            {
                renderers[i].material.color = flashColor;
            }
        }

        yield return new WaitForSeconds(flashDuration);

        // ��ԭ
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null)
            {
                renderers[i].material.color = originalColors[i];
            }
        }
    }
}
