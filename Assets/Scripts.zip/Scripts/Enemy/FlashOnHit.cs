using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class FlashOnHit : MonoBehaviour
{
    [Header("Flash")]
    [SerializeField] private Color flashColor = Color.white;
    [SerializeField] private float flashDuration = 0.08f;

    [Header("Recoil (Optional)")]
    [Tooltip("��ѡ�������ɫ�� CharHitRecoil�����Զ������ܻ�����Ч��")]
    [SerializeField] private CharHitRecoil recoil;

    private Renderer[] renderers;
    private Color[] originalColors;

    private void Awake()
    {
        // �� Recoil����ѡ��
        if (recoil == null)
            recoil = GetComponentInChildren<CharHitRecoil>();

        // �ռ����������
        var all = GetComponentsInChildren<Renderer>();
        var list = new List<Renderer>();
        var colors = new List<Color>();

        foreach (var r in all)
        {
            var mat = r.material;
            if (mat != null && mat.HasProperty("_Color"))
            {
                list.Add(r);
                colors.Add(mat.color);
            }
        }

        renderers = list.ToArray();
        originalColors = colors.ToArray(); 
    }

    /// <summary>
    /// �ⲿ�����ܻ����� + ����
    /// </summary>
    public void Trigger(Vector3 hitPoint, ImpactGrade impact)
    {
        if (!isActiveAndEnabled) return;

        // �� �Ӿ�����
        if (renderers != null && renderers.Length > 0)
        {
            StopAllCoroutines();
            StartCoroutine(FlashRoutine());
        }

        // �� �ܻ�����������ɫ�д������
        if (recoil != null)
            recoil.PlayRecoil(hitPoint, impact);
    }

    private IEnumerator FlashRoutine()
    {
        // ����
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null)
                renderers[i].material.color = flashColor;
        }

        yield return new WaitForSeconds(flashDuration);

        // ��ԭ
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null)
                renderers[i].material.color = originalColors[i];
        }
    }
}
