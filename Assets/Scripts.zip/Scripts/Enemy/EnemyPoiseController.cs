using System;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(EnemyResources))]
public class EnemyPoiseController : MonoBehaviour
{
    [Header("Runtime (ReadOnly)")]
    [SerializeField] private float currentPoise;
    [SerializeField] private bool isBroken;
    [SerializeField] private float breakTimer;
    [SerializeField] private float regenDelayTimer;

    [Header("Debug")]
    [SerializeField] private ImpactContext currentContext = ImpactContext.Default;

    private EnemyResources _resources;
    private EnemyStatsConfig _stats;

    public event Action<ImpactReaction> OnImpactReaction;

    public float CurrentPoise => currentPoise;
    public bool IsBroken => isBroken;
    public ImpactContext CurrentContext => currentContext;
    public ImpactReaction LastReaction { get; private set; } = ImpactReaction.None;
    public ImpactGrade LastImpactGrade { get; private set; } = ImpactGrade.Small;
    public float MaxPoise => _stats != null ? _stats.maxPoise : 0f;

    private void Awake()
    {
        _resources = GetComponent<EnemyResources>();
        _stats = _resources.Stats;

        if (_stats == null)
        {
            Debug.LogError("[EnemyPoise] EnemyStatsConfig is null.", this);
            enabled = false;
            return;
        }

        ResetPoise();
    }

    private void Update()
    {
        float dt = Time.deltaTime;

        // ����״̬��ʱ
        if (isBroken)
        {
            breakTimer -= dt;
            if (breakTimer <= 0f)
            {
                ExitBreak();
            }
            return;
        }

        // �ظ��ӳټ�ʱ
        if (regenDelayTimer > 0f)
        {
            regenDelayTimer -= dt;
            return;
        }

        // ���Իظ�
        if (currentPoise < _stats.maxPoise && _stats.poiseRegenPerSecond > 0f)
        {
            currentPoise += _stats.poiseRegenPerSecond * dt;
            if (currentPoise > _stats.maxPoise)
                currentPoise = _stats.maxPoise;
        }
    }

    public void ResetPoise()
    {
        currentPoise = _stats.maxPoise;
        isBroken = false;
        breakTimer = 0f;
        regenDelayTimer = 0f;
        currentContext = ImpactContext.Default;
    }

    /// <summary>
    /// ���˱�һ�� Attack ����ʱ���á�
    /// ��������� + �������� + ����Ӳֱ��Ӧ��
    /// </summary>
    public ImpactReaction ApplyHit(AttackData attackData, ImpactContext contextOverride = ImpactContext.Default)
    {
        if (_stats == null || attackData == null)
            return ImpactReaction.None;

        if (isBroken)
        {
            var rBroken = ResolveReaction(attackData.impact, ImpactContext.Broken);
            LastReaction = rBroken;
            LastImpactGrade = attackData.impact;
            OnImpactReaction?.Invoke(rBroken);
            return rBroken;
        }

        // 1) ������
        float poiseDamage = attackData.poiseDamage;
        if (poiseDamage > 0f)
        {
            currentPoise -= poiseDamage;
            if (currentPoise < 0f) currentPoise = 0f;

            regenDelayTimer = _stats.poiseRegenDelay;
        }

        // 2) �����Թ��� �� ��������״̬
        if (currentPoise <= 0f)
        {
            EnterBreak();
            var rBreak = ResolveReaction(attackData.impact, ImpactContext.Broken);

            LastReaction = rBreak;
            LastImpactGrade = attackData.impact;
            OnImpactReaction?.Invoke(rBreak);
            return rBreak;
        }

        // 3) ��������£����ݵ�ǰ�����Ĳ��
        currentContext = contextOverride;
        var reaction = ResolveReaction(attackData.impact, currentContext);

        LastReaction = reaction;
        LastImpactGrade = attackData.impact;
        OnImpactReaction?.Invoke(reaction);
        return reaction;
    }


    private void EnterBreak()
    {
        isBroken = true;
        breakTimer = _stats.breakDuration;
        currentPoise = 0f;
        currentContext = ImpactContext.Broken;
        Debug.Log("[EnemyPoise] Enter BREAK state.", this);
    }

    private void ExitBreak()
    {
        isBroken = false;
        currentPoise = _stats.maxPoise;
        currentContext = ImpactContext.Default;
        Debug.Log("[EnemyPoise] Exit BREAK state.", this);
    }

    private ImpactReaction ResolveReaction(ImpactGrade grade, ImpactContext ctx)
    {
        var profile = _stats.impactProfile;
        if (profile == null || profile.rules == null || profile.rules.Count == 0)
            return ImpactReaction.None;

        StateImpactRule rule = null;

        // �Ҷ�Ӧ������
        for (int i = 0; i < profile.rules.Count; i++)
        {
            if (profile.rules[i].state == ctx)
            {
                rule = profile.rules[i];
                break;
            }
        }

        // ���û����������ģ��ͳ����� Default��������
        if (rule == null)
        {
            for (int i = 0; i < profile.rules.Count; i++)
            {
                if (profile.rules[i].state == ImpactContext.Default)
                {
                    rule = profile.rules[i];
                    break;
                }
            }
        }

        if (rule == null)
            return ImpactReaction.None;

        switch (grade)
        {
            case ImpactGrade.Small:
                return rule.smallImpactReaction;
            case ImpactGrade.Medium:
                return rule.mediumImpactReaction;
            case ImpactGrade.Large:
                return rule.largeImpactReaction;
            default:
                return ImpactReaction.None;
        }
    }

    // �Ժ���������� AI ���ֶ��л�����������ģ������ع����ڼ䵱�� HeavyWeapon�������ԼӸ��ӿڣ�
    public void SetContext(ImpactContext ctx)
    {
        currentContext = ctx;
    }
}
