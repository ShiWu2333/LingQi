using UnityEngine;

[DisallowMultipleComponent]
public class BillboardToCamera : MonoBehaviour
{
    [Tooltip("ֻ�� Y ��ת���ʺϵ���ͼ�� / �������ӣ�")]
    [SerializeField] private bool onlyYaw = true;

    private Camera _cam;

    private void LateUpdate()
    {
        if (_cam == null)
            _cam = Camera.main;
        if (_cam == null) return;

        if (onlyYaw)
        {
            // ֻ��ˮƽ���϶���
            Vector3 dir = _cam.transform.position - transform.position;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.0001f) return;

            transform.rotation = Quaternion.LookRotation(dir, Vector3.up);
        }
        else
        {
            // ��ȫ���������
            transform.rotation = Quaternion.LookRotation(
                _cam.transform.position - transform.position,
                Vector3.up);
        }
    }
}
