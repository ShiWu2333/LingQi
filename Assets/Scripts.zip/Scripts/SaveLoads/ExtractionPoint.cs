using UnityEngine;

[RequireComponent(typeof(Collider))]
[DisallowMultipleComponent]
public class ExtractionPoint : MonoBehaviour
{
    [Header("Interact")]
    [SerializeField] private KeyCode interactKey = KeyCode.F;
    [SerializeField] private KeyCode cancelKey = KeyCode.Escape;

    [Header("Refs")]
    [SerializeField] private Transform campSpawnPointOverride; // ��ѡ��������� RunManager ��

    [Header("Runtime (ReadOnly)")]
    [SerializeField] private bool playerInZone;
    [SerializeField] private bool awaitingConfirm;

    private GameObject _player;

    private void Reset()
    {
        // ȷ���� Trigger
        var col = GetComponent<Collider>();
        col.isTrigger = true;
    }

    private void Update()
    {
        if (!playerInZone || _player == null)
            return;

        // Esc ȡ��ȷ��
        if (awaitingConfirm && Input.GetKeyDown(cancelKey))
        {
            awaitingConfirm = false;
            return;
        }

        if (Input.GetKeyDown(interactKey))
        {
            if (!awaitingConfirm)
            {
                // ��һ�ΰ�������ȷ��̬
                awaitingConfirm = true;
                return;
            }

            // �ڶ��ΰ���ȷ�ϳ���
            DoExtract();
        }
    }

    private void DoExtract()
    {
        awaitingConfirm = false;

        var rm = RunManager.Instance;
        if (rm == null)
        {
            Debug.LogError("[ExtractionPoint] RunManager.Instance is null!");
            return;
        }

        // 1) ���ñ��� Run�����˻س�ʼ��ʬ������������ȵȣ�
        rm.ResetRun();

        // 2) ������ҵ�Ӫ��
        Transform camp = campSpawnPointOverride != null ? campSpawnPointOverride : rm.CampSpawnPoint;
        if (camp == null)
        {
            Debug.LogError("[ExtractionPoint] CampSpawnPoint is not assigned!");
            return;
        }

        TeleportPlayerTo(_player, camp.position, camp.rotation);
        playerInZone = false;
    }

    private void TeleportPlayerTo(GameObject player, Vector3 pos, Quaternion rot)
    {
        // ���� CharacterController��ֱ�Ӹ� transform �ᴩģ/����
        var cc = player.GetComponent<CharacterController>();
        if (cc != null) cc.enabled = false;

        player.transform.SetPositionAndRotation(pos, rot);

        if (cc != null) cc.enabled = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        _player = other.gameObject;
        playerInZone = true;
        awaitingConfirm = false;
    }

    private void OnTriggerExit(Collider other)
    {
        if (_player == null) return;
        if (other.gameObject != _player) return;

        playerInZone = false;
        awaitingConfirm = false;
        _player = null;
    }

    // ����֮��� UI �ã����絯��ȷ����壩
    public bool IsPlayerInZone => playerInZone;
    public bool AwaitingConfirm => awaitingConfirm;
}
