using System.Collections;
using UnityEngine;

[DisallowMultipleComponent]
public class PlayerInteractController : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private float interactDistance = 3f;
    [SerializeField] private LayerMask interactLayers = ~0;  // ֻ��� LootContainer �Ĳ�

    [Header("UI")]
    [SerializeField] private InventoryUI inventoryUI;         // ��ұ��� UI
    [SerializeField] private InventoryUI campStorageUI;       // Ӫ�زֿ� UI��Ҳ��һ�� InventoryUI��
    [SerializeField] private LootContainerUI lootContainerUI; // ������ / ʬ�� UI

    [Header("Input")]
    [SerializeField] private KeyCode inventoryKey = KeyCode.B;
    [SerializeField] private KeyCode interactKey = KeyCode.F;

    [Header("Search")]
    [SerializeField] private bool useHoldToSearch = true;   // true = ��ס F �������
    [SerializeField] private float minSearchHold = 0.1f;    // ��ֹ��

    [Header("Debug")]
    [SerializeField] private bool debugDrawRay = false;
    [SerializeField] private string currentFocusName;

    private ILootSource _currentFocus;
    private Coroutine _searchRoutine;
    private bool _isSearching;
    private float _searchProgress; // 0~1��֮����Ա�¶�������� UI

    // Ӫ��״̬
    [SerializeField] private bool _isInCamp = false;

    public float SearchProgress => _searchProgress;
    public bool IsSearching => _isSearching;
    public ILootSource CurrentFocus => _currentFocus;

    /// <summary>��Ӫ�����򴥷������ã���������Ƿ���Ӫ�ء�</summary>
    public void SetInCamp(bool value)
    {
        _isInCamp = value;
    }

    private void Update()
    {
        HandleInventoryToggle();
        UpdateFocus();
        HandleInteract();
        HandleCloseLootContainer();
    }

    // ================== ���� / �ֿ� ���� ==================

    private void HandleInventoryToggle()
    {
        if (!Input.GetKeyDown(inventoryKey))
            return;

        // ��ǰ��Ҫ������״̬����ת��ұ�����ǰ״̬
        bool newVisible = !(inventoryUI != null && inventoryUI.IsVisible);

        // ��ұ���
        if (inventoryUI != null)
        {
            if (newVisible) inventoryUI.Show();
            else inventoryUI.Hide();
        }

        // ��Ӫ�ز������ֿ�
        if (campStorageUI != null && _isInCamp)
        {
            if (newVisible) campStorageUI.Show();
            else campStorageUI.Hide();
        }
        else
        {
            // ����Ӫ�أ�ȷ���ֿ��ǹ��ŵ�
            if (campStorageUI != null && campStorageUI.IsVisible)
                campStorageUI.Hide();
        }
    }

    // ================== ����Ŀ���� ==================

    private void UpdateFocus()
    {
        _currentFocus = null;
        currentFocusName = "";

        Vector3 origin = transform.position + Vector3.up * 1.0f;
        Vector3 dir = transform.forward;

        Ray ray = new Ray(origin, dir);

        if (Physics.Raycast(ray, out var hit, interactDistance, interactLayers, QueryTriggerInteraction.Collide))
        {
            var loot = hit.collider.GetComponentInParent<ILootSource>();
            if (loot != null)
            {
                _currentFocus = loot;
                currentFocusName = hit.collider.name;
            }
        }

        if (debugDrawRay)
        {
            Debug.DrawRay(origin, dir * interactDistance,
                _currentFocus != null ? Color.green : Color.red);
        }
    }

    // ================== F �������� / ������ ==================

    private void HandleInteract()
    {
        if (_currentFocus == null)
            return;

        if (_isSearching)
            return;

        if (useHoldToSearch)
        {
            // ����ģʽ�����¿�ʼ���ɿ��ж�
            if (Input.GetKeyDown(interactKey))
            {
                _searchRoutine = StartCoroutine(CoSearchAndOpen(_currentFocus));
            }

            if (Input.GetKeyUp(interactKey))
            {
                if (_isSearching && _searchRoutine != null)
                {
                    StopCoroutine(_searchRoutine);
                    _searchRoutine = null;
                    _isSearching = false;
                    _searchProgress = 0f;
                }
            }
        }
        else
        {
            // ����ģʽ��ֱ�������������
            if (Input.GetKeyDown(interactKey))
            {
                if (_searchRoutine == null)
                    _searchRoutine = StartCoroutine(CoSearchAndOpen(_currentFocus, ignoreHold: true));
            }
        }
    }

    private IEnumerator CoSearchAndOpen(ILootSource source, bool ignoreHold = false)
    {
        if (source == null)
            yield break;

        _isSearching = true;
        _searchProgress = 0f;

        float duration = Mathf.Max(0.01f, source.GetSearchTime());
        float t = 0f;

        while (t < duration)
        {
            float dt = Time.deltaTime;

            // ���ǳ���ģʽ���ɿ��˼�����ȡ��
            if (!ignoreHold && !Input.GetKey(interactKey) && t > minSearchHold)
            {
                _isSearching = false;
                _searchProgress = 0f;
                _searchRoutine = null;
                yield break;
            }

            t += dt;
            _searchProgress = Mathf.Clamp01(t / duration);

            yield return null;
        }

        _isSearching = false;
        _searchProgress = 1f;
        _searchRoutine = null;

        // ������ɣ��򿪱��� + ���� UI
        if (inventoryUI != null && !inventoryUI.IsVisible)
            inventoryUI.Show();

        if (campStorageUI != null && _isInCamp && !campStorageUI.IsVisible)
            campStorageUI.Show();

        if (lootContainerUI != null)
            lootContainerUI.Show(source);
    }

    // ================== ESC / F �ر� LootContainer ==================

    private void HandleCloseLootContainer()
    {
        if (lootContainerUI == null || !lootContainerUI.IsVisible)
            return;

        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(interactKey))
        {
            lootContainerUI.Hide();

            // ���������ϲ�ã��ѹν���ʱ˳��ص�����
            if (inventoryUI != null && inventoryUI.IsVisible)
                inventoryUI.Hide();

            if (campStorageUI != null && campStorageUI.IsVisible && _isInCamp)
                campStorageUI.Hide();
        }
    }
}
