using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class EnemyLootDropper : MonoBehaviour
{
    [Header("Prefab")]
    [SerializeField] private LootContainer lootContainerPrefab;   // �� PF_CorpseLootContainer
    [SerializeField] private Vector3 spawnOffset = Vector3.zero;

    [Header("Loot Table (Simple)")]
    [Tooltip("�̶����䣨���Խ׶���������������ٻ��ɸ��ʱ���")]
    [SerializeField] private LootTableConfig lootTable;
    [SerializeField] private int overrideRolls = -1; // <0 ��ʾ�� table.rolls

    [Header("Spawn")]
    [SerializeField] private bool destroyContainerWhenEmpty = false;

    private EnemyResources _enemy;
    private bool _dropped;

    private void Awake()
    {
        _enemy = GetComponent<EnemyResources>();
    }

    private void OnEnable()
    {
        if (_enemy != null)
            _enemy.OnDeath += HandleDeath;
    }

    private void OnDisable()
    {
        if (_enemy != null)
            _enemy.OnDeath -= HandleDeath;
    }

    private void HandleDeath()
    {
        DropLoot();
    }

    public void DropLoot()
    {
        if (_dropped) return;
        _dropped = true;

        if (lootContainerPrefab == null)
        {
            Debug.LogWarning("[EnemyLootDropper] lootContainerPrefab is null.");
            return;
        }

        var container = Instantiate(
            lootContainerPrefab,
            transform.position + spawnOffset,
            Quaternion.identity
        );

        // �� �ؼ� 1���Ǽ�Ϊ����ʱ�����ResetRun ��ͳһ Destroy
        RunManager.Instance?.RegisterRuntimeObject(container.gameObject);

        // �� �ؼ� 2��ʬ�����Ӳ����롰�ص�Ԥ��״̬����ֻ��Ҫ�� Reset ʱ������
        container.SetParticipateInRunReset(false);

        // ��ѡ�����˾�����
        container.SetDestroyWhenEmpty(destroyContainerWhenEmpty);

        // ���� loot
        int? rolls = overrideRolls >= 0 ? overrideRolls : (int?)null;
        var loot = LootTableSampler.Roll(lootTable, rolls);

        container.SetLoot(loot);
    }

    [ContextMenu("DEBUG Drop Loot")]
    private void DebugDrop()
    {
        DropLoot();
    }
}
