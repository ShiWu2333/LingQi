using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class InventorySlotUI : MonoBehaviour,
    IPointerClickHandler,
    IBeginDragHandler,
    IDragHandler,
    IEndDragHandler,
    IDropHandler
{
    [Header("UI")]
    [SerializeField] private Image iconImage;
    [SerializeField] private TMP_Text countText;
    [SerializeField] private Image emptyMask;

    public enum OwnerType
    {
        Inventory,
        LootContainer
    }

    // ��ǰ�����������
    public OwnerType ownerType { get; private set; }
    private InventoryUI ownerInventory;
    private LootContainerUI ownerLoot;
    private int slotIndex;

    // ��ǰ��ʾ�����ݣ�������ˢ�� UI��
    private ItemStack _currentStack;

    // ===== ȫ����ק״̬�����ݣ�=====
    private static InventorySlotUI draggingFrom;
    private static ItemStack draggingStack;
    private static bool dropHandledThisDrag;

    // ===== ȫ����קͼ�꣨�Ӿ���=====
    private static Image draggingIcon;
    private static RectTransform draggingIconRect;

    private Canvas rootCanvas;

    private void Awake()
    {
        rootCanvas = GetComponentInParent<Canvas>();
        SetEmpty();
    }

    // ========== ��ʼ�� ==========

    public void InitForInventory(InventoryUI owner, int index)
    {
        ownerType = OwnerType.Inventory;
        ownerInventory = owner;
        ownerLoot = null;
        slotIndex = index;
        SetEmpty();
    }

    public void InitForLoot(LootContainerUI owner, int index)
    {
        ownerType = OwnerType.LootContainer;
        ownerLoot = owner;
        ownerInventory = null;
        slotIndex = index;
        SetEmpty();
    }

    // ========== UI ˢ�� ==========

    public void SetEmpty()
    {
        _currentStack = null;

        if (iconImage != null)
        {
            iconImage.enabled = false;
            iconImage.sprite = null;
        }

        if (countText != null)
            countText.text = "";

        if (emptyMask != null)
            emptyMask.enabled = true;
    }

    public void SetItem(ItemStack stack)
    {
        if (stack == null || stack.item == null || stack.count <= 0)
        {
            SetEmpty();
            return;
        }

        _currentStack = stack;

        if (iconImage != null)
        {
            iconImage.enabled = true;
            iconImage.sprite = stack.item.icon;
        }

        if (countText != null)
        {
            countText.text = stack.count > 1 ? stack.count.ToString() : "";
        }

        if (emptyMask != null)
            emptyMask.enabled = false;
    }

    // ========== �����������������ݲ� ==========

    private ItemStack GetStackFromOwner()
    {
        switch (ownerType)
        {
            case OwnerType.Inventory:
                return ownerInventory != null
                    ? ownerInventory.GetStack(slotIndex)
                    : null;

            case OwnerType.LootContainer:
                return ownerLoot != null
                    ? ownerLoot.GetStack(slotIndex)
                    : null;

            default:
                return null;
        }
    }

    private void SetStackToOwner(ItemStack stack)
    {
        switch (ownerType)
        {
            case OwnerType.Inventory:
                ownerInventory?.SetStack(slotIndex, stack);
                break;
            case OwnerType.LootContainer:
                ownerLoot?.SetStack(slotIndex, stack);
                break;
        }
    }

    // ========== ��קͼ�긨�� ==========

    private void ShowDraggingIcon(Sprite sprite)
    {
        if (sprite == null || rootCanvas == null)
            return;

        if (draggingIcon == null)
        {
            var go = new GameObject("DraggingIcon",
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Image));

            draggingIcon = go.GetComponent<Image>();
            draggingIconRect = go.GetComponent<RectTransform>();
            draggingIcon.raycastTarget = false;
        }

        draggingIcon.sprite = sprite;
        draggingIcon.enabled = true;
        draggingIcon.gameObject.SetActive(true);

        // �ŵ���ǰ Canvas ����
        draggingIconRect.SetParent(rootCanvas.transform, false);

        // �͸���ͼ��ͬ�ߴ�
        if (iconImage != null)
            draggingIconRect.sizeDelta = iconImage.rectTransform.sizeDelta;
    }

    private void HideDraggingIcon()
    {
        if (draggingIcon != null)
            draggingIcon.gameObject.SetActive(false);
    }

    private void UpdateDraggingIconPosition(Vector2 screenPos)
    {
        if (draggingIconRect == null || rootCanvas == null || !draggingIcon.gameObject.activeSelf)
            return;

        // ScreenSpace-Overlay ֱ�Ӹ�ֵ����
        if (rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
        {
            draggingIconRect.position = screenPos;
        }
        else
        {
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                rootCanvas.transform as RectTransform,
                screenPos,
                rootCanvas.worldCamera,
                out var localPos);
            draggingIconRect.localPosition = localPos;
        }
    }

    // ========== ������Ժ������ Shift ����ʰȡ�� ==========

    public void OnPointerClick(PointerEventData eventData)
    {
        // ��ʱ����
    }

    // ========== ��ק ==========

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        var stack = GetStackFromOwner();
        if (stack == null || stack.item == null || stack.count <= 0)
            return;

        draggingFrom = this;
        // ��һ�����ݸ�������
        draggingStack = new ItemStack(stack.item, stack.count);
        dropHandledThisDrag = false;

        // ���Դ���ӣ����ݲ㣩
        SetStackToOwner(null);

        // ��ʾ��קͼ��
        ShowDraggingIcon(stack.item.icon);
        UpdateDraggingIconPosition(eventData.position);

        // ˢ�� UI
        ownerInventory?.Refresh();
        ownerLoot?.Refresh();
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (draggingFrom != this || draggingStack == null)
            return;

        UpdateDraggingIconPosition(eventData.position);
    }

    public void OnDrop(PointerEventData eventData)
    {
        if (draggingFrom == null || draggingStack == null)
            return;

        dropHandledThisDrag = true;

        // Ŀ����ӵĵ�ǰ��Ʒ
        ItemStack targetStack = GetStackFromOwner();

        if (targetStack == null || targetStack.item == null || targetStack.count <= 0)
        {
            // Ŀ��ո�ֱ�ӷ���
            SetStackToOwner(draggingStack);
            draggingStack = null;
        }
        else if (targetStack.item == draggingStack.item)
        {
            // ͬ����Ʒ�����Ժϲ�
            int maxStack = Mathf.Max(1, targetStack.item.maxStack);
            int canMove = Mathf.Max(0, maxStack - targetStack.count);

            if (canMove > 0)
            {
                int move = Mathf.Min(canMove, draggingStack.count);
                targetStack.count += move;
                draggingStack.count -= move;

                // д��Ŀ�����
                SetStackToOwner(targetStack);

                if (draggingStack.count <= 0)
                    draggingStack = null;
            }
            else
            {
                // �Ѿ���ջ��ֱ�ӽ���
                SwapWithTarget(targetStack);
            }
        }
        else
        {
            // ��ͬ��Ʒ������
            SwapWithTarget(targetStack);
        }

        // ���� UI ˢ��
        ownerInventory?.Refresh();
        ownerLoot?.Refresh();
        draggingFrom.ownerInventory?.Refresh();
        draggingFrom.ownerLoot?.Refresh();
    }

    private void SwapWithTarget(ItemStack targetStack)
    {
        // ��Ŀ����ӵĶ������Դ����
        if (draggingFrom != null)
        {
            draggingFrom.SetStackToOwner(targetStack);
        }

        // ��ǰ���ӷ�����ק����һ��
        SetStackToOwner(draggingStack);
        draggingStack = null;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        // ��ק����������ͼ��
        HideDraggingIcon();

        // �����ק����û���κθ��ӽ��գ��ͰѶ����Ż�ԭλ
        if (!dropHandledThisDrag && draggingFrom == this && draggingStack != null)
        {
            SetStackToOwner(draggingStack);
        }

        // ˢ�� UI
        ownerInventory?.Refresh();
        ownerLoot?.Refresh();

        draggingFrom = null;
        draggingStack = null;
        dropHandledThisDrag = false;
    }
}
