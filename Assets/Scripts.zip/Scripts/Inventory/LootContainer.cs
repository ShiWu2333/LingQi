using System.Collections.Generic;
using UnityEngine;

public interface ILootSource
{
    bool IsSearched { get; }
    float GetSearchTime();
    List<ItemStack> TakeAllLoot();
    int SlotCount { get; }
    ItemStack GetSlotStack(int index);
    void SetSlotStack(int index, ItemStack stack);
}

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
public class LootContainer : MonoBehaviour, ILootSource, IRunResettable
{
    [Header("Loot Content")]
    [Tooltip("���������/ʬ����ʵ�ʴ�Ķ����������� Inspector ��ֱ���")]
    [SerializeField] private List<ItemStack> loot = new List<ItemStack>();

    [Header("Search Settings")]
    [SerializeField] private float searchTimeMultiplier = 1.0f;
    [SerializeField] private float minSearchTime = 0.3f;
    [SerializeField] private float maxSearchTime = 5.0f;

    [Header("Flags")]
    [SerializeField] private bool consumeOnSearch = true;
    [SerializeField] private bool destroyWhenEmpty = false;
    [SerializeField] private bool isSearched = false;

    [Header("Run Reset")]
    [Tooltip("��ѡ���������ǡ�����Ԥ����������ResetRun ʱ��ָ�����ʼ״̬��\n����ѡ��������ͨ��������ʱ���ɣ�����ʬ�����ӣ���������ָ���ֻ�ᱻ RunManager Destroy���� RegisterRuntimeObject����")]
    [SerializeField] private bool participateInRunReset = true;

    // ===== ��ʼ���գ�ֻ�� participateInRunReset=true �����壩=====
    private List<ItemStack> _initialLootSnapshot;
    private bool _initialIsSearched;

    public bool IsSearched => isSearched && (loot == null || loot.Count == 0);
    public int SlotCount => loot != null ? loot.Count : 0;

    private void Reset()
    {
        var col = GetComponent<Collider>();
        if (col != null)
            col.isTrigger = true;
    }

    private void Awake()
    {
        if (participateInRunReset)
        {
            CaptureInitialState();
            RunManager.Instance?.RegisterResettable(this);
        }
    }

    private void OnDestroy()
    {
        // �����ԣ�����ж��/����ʱ���Լ����б��Ƴ��������������
        if (participateInRunReset)
            RunManager.Instance?.UnregisterResettable(this);
    }

    private void CaptureInitialState()
    {
        _initialLootSnapshot = new List<ItemStack>();

        if (loot != null)
        {
            foreach (var s in loot)
            {
                if (s == null || s.item == null || s.count <= 0)
                    _initialLootSnapshot.Add(null);
                else
                    _initialLootSnapshot.Add(new ItemStack(s.item, s.count));
            }
        }

        _initialIsSearched = isSearched;
    }

    // ================= IRunResettable =================
    public void ResetToDefault()
    {
        if (!participateInRunReset)
            return;

        if (loot == null)
            loot = new List<ItemStack>();
        else
            loot.Clear();

        if (_initialLootSnapshot != null)
        {
            foreach (var s in _initialLootSnapshot)
            {
                if (s == null)
                    loot.Add(null);
                else
                    loot.Add(new ItemStack(s.item, s.count));
            }
        }

        isSearched = _initialIsSearched;
    }

    // ============== �ⲿ���ýӿڣ��� EnemyLootDropper �ã� ==============
    public void SetParticipateInRunReset(bool value)
    {
        participateInRunReset = value;
    }

    public void SetDestroyWhenEmpty(bool value)
    {
        destroyWhenEmpty = value;
    }

    // ================= ILootSource������ʱ�� =================
    public float GetSearchTime()
    {
        if (loot == null || loot.Count == 0)
            return minSearchTime;

        float maxBase = 0f;

        foreach (var stack in loot)
        {
            if (stack == null || stack.item == null || stack.count <= 0)
                continue;

            float t = stack.item.baseSearchTime;
            if (t > maxBase)
                maxBase = t;
        }

        if (maxBase <= 0f)
            maxBase = minSearchTime;

        float finalTime = maxBase * Mathf.Max(0.01f, searchTimeMultiplier);
        finalTime = Mathf.Clamp(finalTime, minSearchTime, maxSearchTime);
        return finalTime;
    }

    // ================= ILootSource������λ���� =================
    public ItemStack GetSlotStack(int index)
    {
        if (loot == null || index < 0 || index >= loot.Count)
            return null;

        var s = loot[index];
        if (s == null || s.item == null || s.count <= 0)
            return null;

        return s;
    }

    public void SetSlotStack(int index, ItemStack stack)
    {
        if (loot == null)
            loot = new List<ItemStack>();

        while (loot.Count <= index)
            loot.Add(null);

        if (stack == null || stack.item == null || stack.count <= 0)
        {
            loot[index] = null;
        }
        else
        {
            loot[index] = new ItemStack(stack.item, stack.count);
        }

        isSearched = false;
    }

    // ================= ILootSource��ȫ������ =================
    public List<ItemStack> TakeAllLoot()
    {
        var result = new List<ItemStack>();

        if (loot != null)
        {
            foreach (var s in loot)
            {
                if (s == null || s.item == null || s.count <= 0)
                    continue;

                result.Add(new ItemStack(s.item, s.count));
            }
        }

        if (consumeOnSearch)
        {
            loot.Clear();
            isSearched = true;

            if (destroyWhenEmpty && result.Count > 0)
                Destroy(gameObject);
        }

        return result;
    }

    // ============== �����ӿڣ���������ʱ��ս��Ʒ�� ==============
    public void SetLoot(List<ItemStack> newLoot)
    {
        if (loot == null)
            loot = new List<ItemStack>();
        else
            loot.Clear();

        if (newLoot != null)
        {
            foreach (var s in newLoot)
            {
                if (s == null || s.item == null || s.count <= 0)
                    continue;

                loot.Add(new ItemStack(s.item, s.count));
            }
        }

        isSearched = false;
    }
}
