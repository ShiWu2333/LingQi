using UnityEngine;

[DisallowMultipleComponent]
public class PlayerSwordProceduralAnimator : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private PlayerCombatController combat;

    // ��������
    private AttackData currentAttack;
    private SwordMotionConfig motion;

    private float timer;
    private bool playing;

    // �Ƕȶ��ǡ���� baseYaw ��ƫ�ơ�����λ����
    private float _baseLocalYaw;       // ��ʼ localEulerAngles.y
    private float _currentAngle;       // ��ǰ��Խ�
    private float _fromAngle;          // ���ι�����ʼʱ�ĽǶ�
    private float _startAngle;
    private float _endAngle;
    private float _anticipationAngle;
    private float _overshootAngle;
    private float _idleAngle;          // ���� motion.idleAngle

    // �� idle ��״̬
    private bool _returningToIdle;
    private float _idleReturnTimer;
    [SerializeField] private float idleReturnDuration = 0.25f; // �Լ��ɵ�

    private void OnEnable()
    {
        if (combat == null)
            combat = GetComponentInParent<PlayerCombatController>();

        if (combat != null)
        {
            combat.OnAttackStarted += HandleAttackStarted;
            combat.OnAttackEnded += HandleAttackEnded;
        }
    }

    private void OnDisable()
    {
        if (combat != null)
        {
            combat.OnAttackStarted -= HandleAttackStarted;
            combat.OnAttackEnded -= HandleAttackEnded;
        }
    }

    private void Start()
    {
        _baseLocalYaw = transform.localEulerAngles.y;
        _currentAngle = 0f; // ��ʼ��Ϊ idleAngle = 0
        ApplyAngle(_currentAngle);
    }

    private void HandleAttackStarted(AttackData data)
    {
        currentAttack = data;
        motion = data != null ? data.swordMotion : null;

        if (motion == null)
        {
            playing = false;
            return;
        }

        // ���ι����ӵ�ǰ�Ƕȿ�ʼ��֧�� combo ƽ���νӣ�
        _fromAngle = _currentAngle;
        _startAngle = motion.startAngle;
        _endAngle = motion.endAngle;
        _anticipationAngle = motion.startAngle + motion.anticipationOffset;
        _overshootAngle = motion.endAngle + motion.overshootOffset;
        _idleAngle = motion.idleAngle;

        timer = 0f;
        playing = true;

        // ������ڻ� idle������ʱ�ֿ�ʼ�¹������ʹ�� idle �ع�
        _returningToIdle = false;
    }

    private void HandleAttackEnded(AttackData data)
    {
        // û�� combo ������Ż��������ʱ _currentAngle �� overshootAngle
        if (motion != null)
        {
            _returningToIdle = true;
            _idleReturnTimer = 0f;
        }

        playing = false;
        currentAttack = null;
        motion = null;
    }

    private void Update()
    {
        float dt = Time.deltaTime;

        if (playing && currentAttack != null && motion != null)
        {
            timer += dt;

            float s = currentAttack.startup;
            float a = currentAttack.active;
            float r = currentAttack.recovery;
            float total = s + a + r;
            float t = timer;

            if (t < s)
            {
                // STARTUP��fromAngle �� anticipationAngle �� startAngle
                float nt = s > 0f ? t / s : 1f;
                UpdateStartup(nt);
            }
            else if (t < s + a)
            {
                // ACTIVE��anticipationAngle �� endAngle��Slow In��
                float nt = a > 0f ? (t - s) / a : 1f;
                UpdateActive(nt);
            }
            else if (t < total)
            {
                // RECOVERY��endAngle �� overshootAngle��Slow Out��
                float nt = r > 0f ? (t - s - a) / r : 1f;
                UpdateRecovery(nt);
            }
            else
            {
                // ������ AttackState ���� recovery ����ʱ���� OnAttackEnded��
                // ���ﶵ��һ��
                if (!_returningToIdle)
                    HandleAttackEnded(currentAttack);
            }
        }
        else if (_returningToIdle)
        {
            // û���¹�����������Ҫ�� idle
            _idleReturnTimer += dt;
            float nt = Mathf.Clamp01(_idleReturnTimer / idleReturnDuration);

            float angle = Mathf.Lerp(_currentAngle, _idleAngle, EaseOutQuad(nt));
            ApplyAngle(angle);

            if (nt >= 1f)
                _returningToIdle = false;
        }
    }

    // -------- ���׶����� --------

    private void UpdateStartup(float t)
    {
        // Startup �����׶Σ�fromAngle -> anticipationAngle��̧�֣�
        // t: 0~1��ʹ�� EaseOutQuad ����Խ��Խ��
        float eased = EaseOutQuad(t);
        float angle = Mathf.Lerp(_fromAngle, _anticipationAngle, eased);
        ApplyAngle(angle);
    }

    private void UpdateActive(float t)
    {
        // Active: anticipationAngle -> endAngle��Slow In��
        float eased = EaseInQuad(t); // ǰ����������
        float angle = Mathf.Lerp(_anticipationAngle, _endAngle, eased);
        ApplyAngle(angle);
    }

    private void UpdateRecovery(float t)
    {
        float eased = EaseOutQuad(t);    // һ��ʼ�죬��������ͣ
        float angle = Mathf.Lerp(_endAngle, _overshootAngle, eased);
        ApplyAngle(angle);
    }

    // -------- ʵ��д�� Transform --------

    private void ApplyAngle(float attackAngle)
    {
        _currentAngle = attackAngle;
        Vector3 euler = transform.localEulerAngles;
        euler.y = _baseLocalYaw + attackAngle;
        transform.localEulerAngles = euler;
    }

    // ���߹��ߣ�Slow In / Slow Out / EaseInOut
    private float EaseInQuad(float x) => x * x;
    private float EaseOutQuad(float x) => 1f - (1f - x) * (1f - x);

    
}
