using UnityEngine;

[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
[DisallowMultipleComponent]
public class Projectile : MonoBehaviour
{
    private AttackData _attack;
    private LayerMask _targetLayers;
    private MonoBehaviour _owner;   // ������ PlayerCombatController / EnemyAIController / ����

    private float _speed;
    private float _lifeTime;
    private float _timer;

    // homing
    private Transform _homingTarget;
    private float _homingTurnSpeedRad;
    private float _homingHeightOffset;

    [Header("Initial Spread")]
    [Tooltip("����˲�䣬�ڵ�ǰ���򸽽������ƫ�ƽǶȣ��ȣ���0 ��ʾ��ɢ��")]
    [SerializeField] private float initialSpreadAngleDeg = 8f;

    private void Awake()
    {
        var col = GetComponent<Collider>();
        col.isTrigger = true;

        var rb = GetComponent<Rigidbody>();
        rb.useGravity = false;
        rb.isKinematic = true;
    }

    /// <summary>
    /// ��ʼ��Ͷ����
    /// </summary>
    public void Init(
        AttackData attack,
        LayerMask targetLayers,
        MonoBehaviour owner,
        Transform homingTarget = null)
    {
        _attack = attack;
        _targetLayers = targetLayers;
        _owner = owner;

        _speed = attack.projectileSpeed;
        _lifeTime = attack.projectileLifeTime;

        // ===== ��֡ɢ�䣺�ڵ�ǰ���򸽽����һ���Ƕ� =====
        // ����ֻ��ˮƽ��(Y ��)��ɢ�䣬�ʺ϶��� / �����˳����
        if (initialSpreadAngleDeg > 0f)
        {
            float angle = Random.Range(-initialSpreadAngleDeg, initialSpreadAngleDeg);
            transform.rotation = Quaternion.AngleAxis(angle, Vector3.up) * transform.rotation;
        }

        // ===== ׷�ٲ��� =====
        if (attack.projectileHoming && homingTarget != null)
        {
            _homingTarget = homingTarget;
            _homingTurnSpeedRad =
                attack.projectileHomingTurnSpeedDeg * Mathf.Deg2Rad;
            _homingHeightOffset = attack.projectileHomingHeightOffset;
        }
    }

    private void Update()
    {
        float dt = Time.deltaTime;

        // ��׷��
        // ��׷�٣�3D �棩
        if (_homingTarget != null)
        {
            Vector3 targetPos = _homingTarget.position
                                + Vector3.up * _homingHeightOffset;
            Vector3 toTarget = targetPos - transform.position;

            if (toTarget.sqrMagnitude > 0.0001f)
            {
                Vector3 currentDir = transform.forward;

                Vector3 newDir = Vector3.RotateTowards(
                    currentDir,
                    toTarget.normalized,
                    _homingTurnSpeedRad * dt,
                    0f);

                transform.rotation = Quaternion.LookRotation(newDir, Vector3.up);
            }
        }


        // λ��
        transform.position += transform.forward * _speed * dt;

        // ����
        _timer += dt;
        if (_timer >= _lifeTime)
            Destroy(gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        // Layer ����
        if (((1 << other.gameObject.layer) & _targetLayers) == 0)
            return;

        Vector3 hitPoint = other.ClosestPoint(transform.position);

        // ���г���ȼ�
        ImpactGrade impact =
            _attack != null ? _attack.impact : ImpactGrade.Small;

        // ============ ��� 1����ҷ������ӵ�������� ============
        if (_owner is PlayerCombatController playerOwner)
        {
            if (!other.TryGetComponent(out EnemyResources enemy))
                return;

            float damage = 0f;
            if (_attack != null)
                damage = playerOwner.GetFinalDamage(_attack);

            if (damage > 0f)
                enemy.TakeDamage(damage, hitPoint, impact);

            // �������� VFX
            playerOwner.PlayHitVfx(hitPoint, _attack);

            Destroy(gameObject);
            return;
        }

        // ============ ��� 2�����˷������ӵ�������� ============
        if (_owner is EnemyAIController enemyOwner)
        {
            if (!other.TryGetComponent(out PlayerResources playerRes))
                return;

            float damage = (_attack != null) ? _attack.damage : 0f;
            if (damage > 0f)
                playerRes.TakeDamage(damage, hitPoint, impact);

            // �����δ�����õ���Ҳ��������Ч�����ԣ�
            // enemyOwner.PlayHitVfx(hitPoint, _attack);  // ���� EnemyAIController ��������ʵ��

            Destroy(gameObject);
            return;
        }

        // ============ ��� 3������ owner�����ף� ============
        float fallbackDamage = (_attack != null) ? _attack.damage : 0f;
        if (fallbackDamage <= 0f)
        {
            Destroy(gameObject);
            return;
        }

        // ���Դ����
        if (other.TryGetComponent(out EnemyResources enemyFallback))
        {
            enemyFallback.TakeDamage(fallbackDamage, hitPoint, impact);
        }
        // ���ߴ����
        else if (other.TryGetComponent(out PlayerResources playerFallback))
        {
            playerFallback.TakeDamage(fallbackDamage, hitPoint, impact);
        }

        Destroy(gameObject);
    }
}
